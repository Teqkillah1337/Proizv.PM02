﻿using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;

namespace PTO
{
    public class DatabaseHelper
    {
        private readonly string _connectionString;

        public DatabaseHelper()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["UnifiedWindowSystemEntities"].ConnectionString;
        }

        public User AuthenticateUser(string username, string password)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                SELECT u.UserID, u.Username, u.FullName, u.Email, d.DepartmentName
                FROM Users u
                JOIN Departments d ON u.DepartmentID = d.DepartmentID
                WHERE u.Username = @Username AND u.Password = @Password 
                AND d.DepartmentName = 'Производственно-технический отдел'";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                UserID = reader.GetInt32(reader.GetOrdinal("UserID")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                FullName = reader.GetString(reader.GetOrdinal("FullName")),
                                Email = reader.GetString(reader.GetOrdinal("Email")),
                                DepartmentName = reader.GetString(reader.GetOrdinal("DepartmentName"))
                            };
                        }
                    }
                }
            }
            return null;
        }
        public bool SendTechnicalCondition(TechnicalCondition condition)
        {
            // Здесь будет логика отправки ТУ в другой модуль
            // Для примера просто возвращаем true
            return true;
        }


        public List<Application> GetApplications()
        {
            var applications = new List<Application>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                SELECT a.ApplicationID, a.ObjectName, s.StatusName, a.CreationDate, a.Comments
                FROM Applications a
                JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                JOIN ApplicationWorkflow w ON a.ApplicationID = w.ApplicationID
                JOIN Departments d ON w.ToDepartmentID = d.DepartmentID
                WHERE d.DepartmentName = 'Производственно-технический отдел'";

                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            applications.Add(new Application
                            {
                                ApplicationID = reader.GetInt32(reader.GetOrdinal("ApplicationID")),
                                ObjectName = reader.GetString(reader.GetOrdinal("ObjectName")),
                                StatusName = reader.GetString(reader.GetOrdinal("StatusName")),
                                CreationDate = reader.GetDateTime(reader.GetOrdinal("CreationDate")),
                                Description = reader.GetString(reader.GetOrdinal("Comments"))
                            });
                        }
                    }
                }
            }

            return applications;
        }

        public List<TechnicalCondition> GetTechnicalConditions()
        {
            var conditions = new List<TechnicalCondition>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                SELECT ConditionID, ApplicationID, ConditionsText, IsApproved, ApprovalDate
                FROM TechnicalConditions";

                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            conditions.Add(new TechnicalCondition
                            {
                                ConditionID = reader.GetInt32(reader.GetOrdinal("ConditionID")),
                                ApplicationID = reader.GetInt32(reader.GetOrdinal("ApplicationID")),
                                ConditionsText = reader.GetString(reader.GetOrdinal("ConditionsText")),
                                IsApproved = reader.GetBoolean(reader.GetOrdinal("IsApproved")),
                                CreatedAt = reader.GetDateTime(reader.GetOrdinal("ApprovalDate"))
                            });
                        }
                    }
                }
            }

            return conditions;
        }
        public List<TechnicalCondition> GetOverdueTechnicalConditions()
        {
            var conditions = new List<TechnicalCondition>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
                SELECT ConditionID, ApplicationID, ConditionsText, IsApproved, ApprovalDate
                FROM TechnicalConditions
                WHERE ApprovalDate IS NOT NULL AND ApprovalDate < DATEADD(day, -14, GETDATE()) AND IsApproved = 0";

                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            conditions.Add(new TechnicalCondition
                            {
                                ConditionID = reader.GetInt32(reader.GetOrdinal("ConditionID")),
                                ApplicationID = reader.GetInt32(reader.GetOrdinal("ApplicationID")),
                                ConditionsText = reader.GetString(reader.GetOrdinal("ConditionsText")),
                                IsApproved = reader.GetBoolean(reader.GetOrdinal("IsApproved")),
                                CreatedAt = reader.GetDateTime(reader.GetOrdinal("ApprovalDate"))
                            });
                        }
                    }
                }
            }

            return conditions;
        }

        public void ProcessApplication(int applicationId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var updateApplicationQuery = @"
                        UPDATE Applications 
                        SET StatusID = (SELECT StatusID FROM ApplicationStatuses WHERE StatusName = 'Рассматривается'), 
                            ModificationDate = GETDATE() 
                        WHERE ApplicationID = @ApplicationID";

                        var insertWorkflowQuery = @"
                        INSERT INTO ApplicationWorkflow 
                        (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, ActionDate, ProcessingDeadline) 
                        VALUES 
                        (@ApplicationID, 
                         (SELECT DepartmentID FROM Departments WHERE DepartmentName = 'Производственно-технический отдел'),
                         (SELECT DepartmentID FROM Departments WHERE DepartmentName = 'Проектно-сметный отдел'),
                         (SELECT StatusID FROM ApplicationStatuses WHERE StatusName = 'Рассматривается'),
                         GETDATE(), 
                         14)";

                        using (var updateCmd = new SqlCommand(updateApplicationQuery, connection, transaction))
                        {
                            updateCmd.Parameters.AddWithValue("@ApplicationID", applicationId);
                            updateCmd.ExecuteNonQuery();
                        }

                        using (var workflowCmd = new SqlCommand(insertWorkflowQuery, connection, transaction))
                        {
                            workflowCmd.Parameters.AddWithValue("@ApplicationID", applicationId);
                            workflowCmd.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
        public bool AddTechnicalCondition(TechnicalCondition condition)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
            INSERT INTO TechnicalConditions 
            (ApplicationID, ConditionsText, IsApproved, ApprovalDate)
            VALUES 
            (@ApplicationID, @ConditionsText, @IsApproved, @ApprovalDate)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ApplicationID", condition.ApplicationID);
                    command.Parameters.AddWithValue("@ConditionsText", condition.ConditionsText);
                    command.Parameters.AddWithValue("@IsApproved", condition.IsApproved);
                    command.Parameters.AddWithValue("@ApprovalDate", condition.CreatedAt);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool UpdateTechnicalCondition(TechnicalCondition condition)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"
            UPDATE TechnicalConditions 
            SET ApplicationID = @ApplicationID,
                ConditionsText = @ConditionsText,
                IsApproved = @IsApproved,
                ApprovalDate = @ApprovalDate
            WHERE ConditionID = @ConditionID";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ConditionID", condition.ConditionID);
                    command.Parameters.AddWithValue("@ApplicationID", condition.ApplicationID);
                    command.Parameters.AddWithValue("@ConditionsText", condition.ConditionsText);
                    command.Parameters.AddWithValue("@IsApproved", condition.IsApproved);
                    command.Parameters.AddWithValue("@ApprovalDate", condition.CreatedAt);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool DeleteTechnicalCondition(int conditionId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "DELETE FROM TechnicalConditions WHERE ConditionID = @ConditionID";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ConditionID", conditionId);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
    }

}