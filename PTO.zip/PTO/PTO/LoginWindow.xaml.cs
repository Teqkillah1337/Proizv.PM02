﻿using System;
using System.Windows;

namespace PTO
{
    public partial class LoginWindow : Window
    {
        private DatabaseHelper _dbHelper;

        public LoginWindow()
        {
            InitializeComponent();
            _dbHelper = new DatabaseHelper();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var user = _dbHelper.AuthenticateUser(txtUsername.Text, txtPassword.Password);

                if (user != null)
                {
                    var mainWindow = new MainWindow(user);
                    mainWindow.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль",
                                    "Ошибка входа",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка входа: {ex.Message}",
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }
    }
}
