﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace PTO
{
    public partial class MainWindow : Window
    {
        private DatabaseHelper _dbHelper;
        private User _currentUser;
        private DispatcherTimer _overdueTimer;

        public MainWindow(User user)
        {
            InitializeComponent();
            _dbHelper = new DatabaseHelper();
            _currentUser = user;

            tbUserName.Text = user.FullName;
            LoadData();
            SetupOverdueNotification();
        }
        private void SetupOverdueNotification()
        {
            _overdueTimer = new DispatcherTimer();
            _overdueTimer.Interval = TimeSpan.FromSeconds(30); //интервал проверки 30 секунд
            _overdueTimer.Tick += OverdueTimer_Tick;
            _overdueTimer.Start();
        }
        private void OverdueTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                var overdueConditions = _dbHelper.GetOverdueTechnicalConditions();

                if (overdueConditions.Any())
                {
                    overdueNotification.Visibility = Visibility.Visible;
                    overdueNotificationText.Text = $"Внимание! {overdueConditions.Count} просроченных технических условий";

                    // Анимация мигания
                    var blinkAnimation = new DoubleAnimation
                    {
                        From = 1.0,
                        To = 0.3,
                        Duration = TimeSpan.FromSeconds(0.5),
                        AutoReverse = true,
                        RepeatBehavior = RepeatBehavior.Forever
                    };
                    overdueNotification.BeginAnimation(OpacityProperty, blinkAnimation);
                }
                else
                {
                    overdueNotification.Visibility = Visibility.Collapsed;
                    overdueNotification.BeginAnimation(OpacityProperty, null); //останавливаем анимацию, когда нет просроченных задач
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка проверки просроченных документов: {ex.Message}");
            }
        }
        private void SendTechnicalCondition_Click(object sender, RoutedEventArgs e)
        {
            var selectedCondition = dgTechnicalConditions.SelectedItem as TechnicalCondition;

            if (selectedCondition != null)
            {
                try
                {
                    bool result = _dbHelper.SendTechnicalCondition(selectedCondition);

                    if (result)
                    {
                        MessageBox.Show("Техническое условие успешно отправлено!",
                                        "Уведомление",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Не удалось отправить техническое условие.",
                                        "Ошибка",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка отправки: {ex.Message}",
                                    "Ошибка",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите техническое условие для отправки.",
                                "Предупреждение",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
            }
        }
        private void LoadData()
        {
            try
            {
                dgApplications.ItemsSource = _dbHelper.GetApplications();
                dgTechnicalConditions.ItemsSource = _dbHelper.GetTechnicalConditions();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}",
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void ProcessApplication_Click(object sender, RoutedEventArgs e)
        {
            var selectedApplication = dgApplications.SelectedItem as Application;
            if (selectedApplication != null)
            {
                try
                {
                    _dbHelper.ProcessApplication(selectedApplication.ApplicationID);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка обработки заявки: {ex.Message}",
                                    "Ошибка",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Error);
                }
            }
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }
        private void AddTechnicalCondition_Click(object sender, RoutedEventArgs e)
        {
            var editor = new TechnicalConditionEditor();
            if (editor.ShowDialog() == true)
            {
                try
                {
                    if (_dbHelper.AddTechnicalCondition(editor.Condition))
                    {
                        MessageBox.Show("Техническое условие успешно добавлено", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось добавить техническое условие", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EditTechnicalCondition_Click(object sender, RoutedEventArgs e)
        {
            var selectedCondition = dgTechnicalConditions.SelectedItem as TechnicalCondition;
            if (selectedCondition == null)
            {
                MessageBox.Show("Выберите техническое условие для редактирования", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var editor = new TechnicalConditionEditor(selectedCondition);
            if (editor.ShowDialog() == true)
            {
                try
                {
                    if (_dbHelper.UpdateTechnicalCondition(editor.Condition))
                    {
                        MessageBox.Show("Техническое условие успешно обновлено", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось обновить техническое условие", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteTechnicalCondition_Click(object sender, RoutedEventArgs e)
        {
            var selectedCondition = dgTechnicalConditions.SelectedItem as TechnicalCondition;
            if (selectedCondition == null)
            {
                MessageBox.Show("Выберите техническое условие для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Вы уверены, что хотите удалить это техническое условие?",
                               "Подтверждение удаления",
                               MessageBoxButton.YesNo,
                               MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    if (_dbHelper.DeleteTechnicalCondition(selectedCondition.ConditionID))
                    {
                        MessageBox.Show("Техническое условие успешно удалено", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось удалить техническое условие", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}