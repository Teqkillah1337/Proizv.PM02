﻿namespace PTO
{
    public partial class App : System.Windows.Application
    {
    }
}

