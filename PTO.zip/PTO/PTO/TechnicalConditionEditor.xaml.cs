﻿using System;
using System.Windows;

namespace PTO
{
    public partial class TechnicalConditionEditor : Window
    {
        public TechnicalCondition Condition { get; private set; }

        public TechnicalConditionEditor(TechnicalCondition condition = null)
        {
            InitializeComponent();

            if (condition != null)
            {
                Condition = condition;
                tbApplicationID.Text = condition.ApplicationID.ToString();
                tbConditionsText.Text = condition.ConditionsText;
                cbIsApproved.IsChecked = condition.IsApproved;
                dpApprovalDate.SelectedDate = condition.CreatedAt;
            }
            else
            {
                Condition = new TechnicalCondition();
                dpApprovalDate.SelectedDate = DateTime.Now;
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(tbApplicationID.Text, out int appId))
            {
                MessageBox.Show("Введите корректный ID заявки");
                return;
            }

            if (string.IsNullOrWhiteSpace(tbConditionsText.Text))
            {
                MessageBox.Show("Введите текст технического условия");
                return;
            }

            Condition.ApplicationID = appId;
            Condition.ConditionsText = tbConditionsText.Text;
            Condition.IsApproved = cbIsApproved.IsChecked ?? false;
            Condition.CreatedAt = dpApprovalDate.SelectedDate ?? DateTime.Now;

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
