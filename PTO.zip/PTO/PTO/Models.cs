﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTO
{
    public class Application
    {
        public int ApplicationID { get; set; }
        public string ObjectName { get; set; }
        public string StatusName { get; set; }
        public DateTime CreationDate { get; set; }
        public string Description { get; set; }
    }

    public class TechnicalCondition
    {
        public int ConditionID { get; set; }
        public int ApplicationID { get; set; }
        public string ConditionsText { get; set; }
        public bool IsApproved { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class User
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string DepartmentName { get; set; }
        public string Email { get; set; }
    }

}
